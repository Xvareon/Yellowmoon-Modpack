![alt tag](http://i.imgur.com/RTNLsgQ.png)

Updates
------
This is a fork of theCyanideX's Unity Resource Pack for Minecraft that updates some modded textures for 1.12.2

Tutorials
------
![alt tag](http://i.imgur.com/9NJg2D3.png)
![alt tag](http://i.imgur.com/EdA2hQm.png)


Photoshop Template
------
I hope this may be of use to those of you interested in texturing for Unity; I've tried to include as many samples and details as possible to start you off in the right direction. You can download the PSD [here](https://www.dropbox.com/s/d3tzqpg0ul8f9q6/unityTemplate.psd?dl=1 "Unity - PSD").

Installation
------
Click the green _Clone or download_ button on the top right and then click _Download ZIP_. Once you've finished downloading, un-zip the file to your `.minecraft/resourcepacks` folder.

Contact
------
If you have any questions, please message me on Twitter @theCyanideX or in the #MinecraftUnity IRC channel. Thanks!
